<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($gnl->title); ?> - <?php echo e($gnl->subtitle); ?>  </title>
    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/')); ?>/logo/icon.png" type="image/x-icon">
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/fontend/css/bootstrap.min.css">
    <!-- icofont -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/fontend/css/fontawesome.min.css">
    <!-- animate.css -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/fontend/css/animate.css">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/fontend/css/owl.carousel.min.css">
    <!-- magnific popup -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/fontend/css/magnific-popup.css">
    <!-- stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/fontend/css/style.css">
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/fontend/css/responsive.css">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>


<!-- navbar area start -->
<?php echo $__env->make('fontend.include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- navbar area end -->

<!-- header area start -->
<?php echo $__env->make('fontend.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- header area end -->

<?php echo $__env->yieldContent('content'); ?>

<!-- footer area start -->
<?php echo $__env->make('fontend.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="copyright-area dark-blug-lg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <span class="copytext">&copy; <?php echo e(date('Y')); ?>. All Rights Reserved By <?php echo e($gnl->title); ?>.</span>
            </div>
        </div>
    </div>
</div>
<!-- footer area end -->

<!-- preloader area start -->
<div class="preloader" id="preloader">
    <div class="preloader-inner">
        <div class="preloader-container">
            <div class="item item-1"></div>
            <div class="item item-2"></div>
            <div class="item item-3"></div>
            <div class="item item-4"></div>
        </div>
    </div>
</div>
<!-- preloader area end -->


<!-- back to top start -->
<div class="back-to-top">
    <i class="fas fa-rocket"></i>
</div>
<!-- back to top end -->

<!-- jquery -->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/jquery.js"></script>
<!-- popper -->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/popper.min.js"></script>
<!-- bootstrap -->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/bootstrap.min.js"></script>
<!-- way poin js-->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/waypoints.min.js"></script>
<!-- owl carousel -->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/owl.carousel.min.js"></script>
<!-- magnific popup -->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/jquery.magnific-popup.js"></script>
<!-- wow js-->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/wow.min.js"></script>
<!-- counterup js-->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/jquery.counterup.min.js"></script>
<!-- main -->
<script src="<?php echo e(url('/')); ?>/assets/fontend/js/main.js"></script>
<?php echo $__env->yieldContent('js'); ?>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
    <?php if(Session::has('msg')): ?>
    swal("<?php echo e(Session::get('msg')); ?>", "", "success");
    <?php endif; ?>

    <?php if(Session::has('alert')): ?>
    swal("<?php echo e(Session::get('alert')); ?>", "", "warning");
    <?php endif; ?>
</script>
</body>

</html>