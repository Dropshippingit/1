<?php $__env->startSection('page_styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="tile">
        <div class="tile-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-info">
                            <div class="caption">
                                <h2 style="text-align: center;color: white">Card Category Header</h2>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-scrollable table-responsive">
                                <form role="form" method="POST" action="<?php echo e(route('admin.cardheader.submit')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <h4>Title</h4>
                                        <input type="text" value="<?php echo e($gnl->attorney_header_title); ?>" class="form-control" id="contact_number" name="attorney_header_title" >
                                    </div>
                                    <div class="form-group">
                                        <h4>Sort Description</h4>
                                        <textarea class="form-control" id="footer" name="attorney_header_des" rows="7"><?php echo $gnl-> attorney_header_des; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success btn-block">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="tile">
        <div class="tile-body">
        <div class="card success">
            <div class="card-header bg-info">

                <h2 style="color: #fff; text-transform: uppercase;">Card category

                    <a class="btn btn-dark pull-right" data-toggle="modal" data-target="#cardcategory">
                        <i class="fa fa-plus"></i> New Category
                    </a>
                </h2>


            </div>
            <div class="card-body">
                <div class="table-scrollable table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th width="20%">Image</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $all_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img style="width: 150px;" src="<?php echo e(asset($cat->image)); ?>">
                                </td>
                                <td>
                                    <?php echo e($cat->cat_name); ?>

                                </td>
                                <td>
                                    <?php if($cat->status == 1): ?>
                                        <label class="badge badge-success">ACTIVE</label>
                                    <?php else: ?>
                                        <label class="badge badge-danger">INACTIVE</label>
                                    <?php endif; ?>
                                </td>


                                <td>
                                    <button class="btn btn-info etdbtn" data-toggle="modal" data-target="#editfeatures<?php echo e($cat->id); ?>" data-id="<?php echo e($cat->id); ?>">Edit</button>



                                    <div id="editfeatures<?php echo e($cat->id); ?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">


                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Edit Category </h4>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                                                </div>
                                                <div class="modal-body">
                                                    <form role="form" method="POST" action="<?php echo e(route('admin.catagoryupdate')); ?>" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>


                                                        <div class="form-group">
                                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                                <div class="fileinput-new thumbnail" >
                                                                    <img src="<?php echo e(asset($cat->image)); ?>" alt="" style="width: 100%;height: 200px"/> </div>
                                                                <div class="fileinput-preview fileinput-exists thumbnail" > </div>
                                                                <div>
                                        <span class="btn btn-success btn-file">
                                            <span class="fileinput-new"> Change Photo </span>
                                            <span class="fileinput-exists"> Change </span>
                                            <input type="file" name="image"> </span>
                                                                    <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                                </div>
                                                            </div>
                                                        </div>



                                                        <div class="form-group">
                                                            <strong>Category Name</strong>
                                                            <input type="hidden" name="id" value="<?php echo e($cat->id); ?>">
                                                            <input type="text"  class="form-control" value="<?php echo e($cat->cat_name); ?>"  name="cat_name" >

                                                        </div>

                                                        <div class="form-group">
                                                            <strong>Category Status</strong>
                                                            <select name="status" class="form-control">
                                                                <?php if($cat->status == 1): ?>
                                                                    <option value="1" selected>ACTIVE</option>
                                                                    <option value="0">INACTIVE</option>
                                                                <?php else: ?>
                                                                    <option value="0" selected>INACTIVE</option>
                                                                    <option value="1">ACTIVE</option>
                                                                <?php endif; ?>

                                                            </select>
                                                        </div>


                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-success pull-left">Update</button>
                                                        </div>
                                                    </form>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                    </table>
                    <?php echo e($all_cat->links()); ?>

                </div>
            </div>
        </div>
        </div>
    </div>


    <div id="cardcategory" class="modal fade" role="dialog">
        <div class="modal-dialog">


            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Create Category</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>
                <div class="modal-body">
                    <form role="form" method="POST" action="<?php echo e(route('admin.category.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">


                            <div class="form-group">



                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">
                                    </div>
                                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width:100%; max-height: 100%;"> </div>
                                    <div>
                                        <span class="btn btn-success btn-file">
                                            <span class="fileinput-new"> Upload Photo </span>
                                            <span class="fileinput-exists"> Change </span>
                                            <input type="file" name="image"> </span>
                                        <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                    </div>
                                </div>
                            </div>



                            <div class="form-group">
                                <strong>Card Category Name</strong>
                                <input type="text"  class="form-control" id="name" name="cat_name" >
                            </div>

                        </div>


                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success ">Create</button>
                        </div>

                    </form>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>

    <script>
        $(document).ready(function () {



            $('.catdelete').click(function (e) {
                e.preventDefault();
                $('#deletecat').modal('show');
                var id = $(this).data('id');
                $('.delid').val(id);
            })

        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>