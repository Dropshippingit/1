<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- login page content area start -->
    <section class="login-page-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title">
                        <h2 class="title">Login Your Account</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="login-form-wrapper"><!-- login form wrapper -->


                        <form  action="<?php echo e(route('login')); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            <div class="form-element has-icon margin-bottom-20">
                                <input type="text" class="input-field" name="username" value="<?php echo e(old('username')); ?>" placeholder="Enter username">
                                <div class="the-icon">
                                    <i class="far fa-user"></i>
                                </div>
                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                        <strong><?php echo e($errors->first('username')); ?></strong>
                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-element has-icon margin-bottom-20">
                                <input type="password" class="input-field" name="password"  placeholder="Enter Password">
                                <div class="the-icon">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="btn-wrapper margin-bottom-20">
                                <div class="left-content">
                                    <input type="submit" class="submit-btn" value="Login">
                                </div>

                            </div>
                            <div class="from-footer">
                                <span class="ftext">Not a member?  <a href="<?php echo e(url('register')); ?>">Create an Account</a></span>
                            </div>
                        </form>
                    </div><!-- //. login form wrapper -->
                </div>
            </div>
        </div>
    </section>
    <!-- login page content area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>