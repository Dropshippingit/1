<?php $__env->startSection('content'); ?>

    <!-- testimonial page content area start-->
    <div class="testimonial-page-conent">
        <div class="container">
            <div class="row">


                   <div class="col-lg-4 col-md-6">
                       <a href="<?php echo e(url('home/my-card')); ?>">
                       <div class="single-testimonial-item text-center" style="border: 1px solid #ba5adf;"><!-- single testimonial item -->

                           <div class="content">
                               <h4 class="name">Total Bought Card</h4>
                               <span class="post" style="font-size: 24px;"><?php echo e(\App\card::where('user_id', \Illuminate\Support\Facades\Auth::id())->count()); ?></span>
                           </div>

                       </div><!-- //.single testimonial item -->
                       </a>
                   </div>

                <div class="col-lg-4 col-md-6">
                    <a href="<?php echo e(url('home/used-card')); ?>">
                        <div class="single-testimonial-item text-center" style="border: 1px solid #ba5adf;"><!-- single testimonial item -->

                            <div class="content">
                                <h4 class="name">Total Used Card</h4>
                                <span class="post" style="font-size: 24px;"><?php echo e(\App\card::where('user_id', \Illuminate\Support\Facades\Auth::id())->where('status',0)->count()); ?></span>
                            </div>

                        </div><!-- //.single testimonial item -->
                    </a>
                   </div>

                <div class="col-lg-4 col-md-6">
                    <a href="<?php echo e(url('home/my-card')); ?>">
                        <div class="single-testimonial-item text-center" style="border: 1px solid #ba5adf;"><!-- single testimonial item -->

                            <div class="content">
                                <h4 class="name">Total Unused Card</h4>
                                <span class="post" style="font-size: 24px;"><?php echo e(\App\card::where('user_id', \Illuminate\Support\Facades\Auth::id())->where('status',1)->count()); ?></span>
                            </div>

                        </div><!-- //.single testimonial item -->
                    </a>
                   </div>

                <div class="col-lg-4 col-md-6">
                    <a href="<?php echo e(url('home/transaction')); ?>">
                        <div class="single-testimonial-item text-center" style="border: 1px solid #ba5adf;"><!-- single testimonial item -->

                            <div class="content">
                                <h4 class="name">Transaction Log</h4>
                                <span class="post">Current Balance: <?php echo e(\Illuminate\Support\Facades\Auth::user()->balance); ?> <?php echo e($gnl->cur); ?></span>
                            </div>

                        </div><!-- //.single testimonial item -->
                    </a>
                   </div>

                <div class="col-lg-4 col-md-6">
                    <a href="<?php echo e(url('home/deposit')); ?>">
                        <div class="single-testimonial-item text-center" style="border: 1px solid #ba5adf;"><!-- single testimonial item -->

                            <div class="content">
                                <h4 class="name">Deposit Now</h4>
                                <span class="post">Total Payment Method: <?php echo e(\App\Gateway::where('status', 1)->count()); ?></span>
                            </div>

                        </div><!-- //.single testimonial item -->
                    </a>
                   </div>

                <div class="col-lg-4 col-md-6">
                    <a href="<?php echo e(url('home/select-category')); ?>">
                        <div class="single-testimonial-item text-center" style="border: 1px solid #ba5adf;"><!-- single testimonial item -->

                            <div class="content">
                                <h4 class="name">Buy Card</h4>
                                <span class="post">Total Card Category: <?php echo e(\App\cardcategory::where('status', 1)->count()); ?></span>
                            </div>

                        </div><!-- //.single testimonial item -->
                    </a>
                   </div>



            </div>
        </div>
    </div>
    <!-- testimonial page content area end-->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>