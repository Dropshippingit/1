<section class="footer-area blue-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="footer-widget about"><!-- footer widget -->
                    <div class="widget-body">
                        <a href="<?php echo e(url('/')); ?>" class="footer-logo">
                            <img style="width: 100%;" src="<?php echo e(asset('assets/images/')); ?>/logo/logo.png" alt="footer logo">
                        </a>

                        <p><?php echo e($gnl->footer); ?></p>
                        <ul class="social-icons">
                            <?php $__currentLoopData = $icon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($ic->icon); ?>"><a href="<?php echo e($ic->link); ?>"><i class="fab fa-<?php echo e($ic->icon); ?>"></i></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </ul>
                    </div>
                </div><!-- //.footer widget -->
            </div>
            <div class="col-lg-3">
                <div class="footer-widget"><!-- footer widget -->
                    <div class="widget-title">
                        <h4 class="title">Links</h4>
                    </div>
                    <div class="widget-body">
                        <ul>
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(route('user.about')); ?>">About us</a></li>
                            <li><a href="<?php echo e(route('contact')); ?>">Contact us</a></li>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        </ul>
                    </div>
                </div><!-- //.footer widget -->
            </div>

            <div class="col-lg-4">
                <div class="footer-widget contact"><!-- footer widget -->
                    <div class="widget-title">
                        <h4 class="title">Contact Us</h4>
                    </div>
                    <div class="widget-body">
                        <span class="details"><?php echo e($gnl->website_email_address); ?></span>
                        <span class="details"><?php echo e($gnl->website_number); ?></span>
                        <span class="details"><?php echo e($gnl->website_address); ?></span>
                    </div>
                </div><!-- //.footer widget -->
            </div>
        </div>
    </div>
</section>