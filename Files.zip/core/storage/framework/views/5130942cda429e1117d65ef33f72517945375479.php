

<?php $__env->startSection('content'); ?>

    <!-- blog page content area start-->
    <div class="blog-details-page-conent">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 single-blog-details-inner-wrapper">
                    <div class="single-blog-details-post text-center"><!-- single blog page -->
                        <h3 style="color: #cc0000;">Sorry! Page Not Found</h3><br>
                        <h4><a href="<?php echo e(route('home')); ?>"><button class="btn btn-info ">Back to Home</button></a></h4>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- blog page content area end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>