<?php $__env->startSection('page_styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>






    <div class="tile">
        <div class="card success">
            <div class="card-header bg-info">

                <h2 style="color: #fff; text-transform: uppercase;">Card subcategory

                    <a class="btn btn-dark pull-right" data-toggle="modal" data-target="#cardcategory">
                        <i class="fa fa-plus"></i> New subCategory
                    </a>
                </h2>


            </div>
            <div class="card-body">
                <div class="table-scrollable">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>Category Name</th>
                            <th>Sub Category Name </th>
                            <th width="20%">Price</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $subcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($cat->sub_cat->cat_name); ?>

                                </td>
                                <td>
                                    <?php echo e($cat->name); ?>

                                </td>
                                <td>
                                    <?php echo e($cat->price); ?> <?php echo e($gnl->cur); ?>

                                </td>
                                <td>
                                    <?php if($cat->status == 1): ?>
                                        <label class="badge badge-success">ACTIVE</label>
                                    <?php else: ?>
                                        <label class="badge badge-danger">INACTIVE</label>
                                    <?php endif; ?>
                                </td>


                                <td>
                                    <button class="btn btn-info etdbtn" data-toggle="modal" data-target="#editfeatures<?php echo e($cat->id); ?>" data-id="<?php echo e($cat->id); ?>">Edit</button>



                                    <div id="editfeatures<?php echo e($cat->id); ?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">


                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Edit Category </h4>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                                                </div>
                                                <div class="modal-body">
                                                    <form role="form" method="POST" action="<?php echo e(route('admin.subcatagoryupdate', $cat->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">


                                                            <div class="form-group">
                                                                <strong>Select Category</strong>
                                                                <select class="form-control" name="cat_id">
                                                                    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option <?php echo e($cat->cat_id == $data->id ? 'selected':''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->cat_name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>

                                                            </div>

                                                            <div class="form-group">
                                                                <strong>Sub Category Name</strong>
                                                                <input type="text"  class="form-control" value="<?php echo e($cat->name); ?>" name="name" placeholder="Name" >
                                                            </div>

                                                            <div class="form-group">
                                                                <strong>Card Price</strong>
                                                                <div class="input-group">
                                                                    <input class="form-control" name="price" value="<?php echo e($cat->price); ?>" type="text" placeholder="Price">
                                                                    <div class="input-group-prepend">
                                                                    <span class="input-group-text">
                                                                    <?php echo e($gnl->cur); ?>

                                                                    </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <strong>Category Status</strong>
                                                                <select name="status" class="form-control">
                                                                    <option <?php echo e($cat->status == 1? 'selected':''); ?> value="1" selected>ACTIVE</option>
                                                                    <option <?php echo e($cat->status == 0? 'selected':''); ?> value="0">INACTIVE</option>
                                                                </select>
                                                            </div>

                                                        </div>


                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-success ">Update</button>
                                                        </div>

                                                    </form>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                    </table>
                    <?php echo e($subcat->links()); ?>

                </div>
            </div>
        </div>
    </div>






    <div id="cardcategory" class="modal fade" role="dialog">
        <div class="modal-dialog">


            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Create Subcategory</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>


                <div class="modal-body">
                    <form role="form" method="POST" action="<?php echo e(route('admin.subcategory.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">


                            <div class="form-group">
                                <strong>Select Category</strong>
                                <select class="form-control" name="cat_id">
                                    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->cat_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>

                            <div class="form-group">
                                <strong>Sub Category Name</strong>
                                <input type="text"  class="form-control" name="name" placeholder="Name" >
                            </div>

                            <div class="form-group">
                                <strong>Card Price</strong>
                                <div class="input-group">
                                    <input class="form-control" name="price" type="text" placeholder="Price">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                        <?php echo e($gnl->cur); ?>

                                        </span>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success ">Create</button>
                        </div>

                    </form>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>

    <script>
        $(document).ready(function () {



            $('.catdelete').click(function (e) {
                e.preventDefault();
                $('#deletecat').modal('show');
                var id = $(this).data('id');
                $('.delid').val(id);
            })

        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>