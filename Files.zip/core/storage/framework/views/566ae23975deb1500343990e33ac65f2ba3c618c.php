<?php $__env->startSection('content'); ?>

    <div class="tile">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <div class="caption">
                            <h2 style="text-align: center; color: white">Send Email To All Subscriber </h2>
                        </div>

                    </div>
                    <div class="card-body">
                        <div class="table-scrollable">
                            <form role="form" method="POST" action="<?php echo e(route('subcribe.mail')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <h4>Subject</h4>
                                    <input type="text" class="form-control" name="subject" >
                                </div>

                                <div class="form-group">
                                    <h4>Message</h4>
                                    <textarea class="form-control"  name="mail_des" rows="10"></textarea>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-block">Send</button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>