<?php $__env->startSection('page_styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="tile">
        <div class="card success col-md-6 offset-3">
            <br>
            <div class="card-header bg-info">
                <h2 style="color: #fff; text-transform: uppercase;">Create Card </h2>
            </div>
            <div class="card-body">
                <form role="form" method="POST" action="<?php echo e(route('admin.card.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <strong>Select Sub-Category</strong>
                            <select class="form-control" name="category_id">
                                <?php $__currentLoopData = $cardcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?> (Cat Name: <?php echo e($cat->sub_cat->cat_name); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <strong>Card Image (OPTIONAL And It will be hidden for Unpaid User)  </strong>
                            <input type="file"  class="form-control" id="name" name="card_image">
                        </div>

                        <div class="form-group">
                            <strong>Card Details</strong>
                            <textarea  class="form-control" id="val1" rows="3" name="card_details"></textarea>
                        </div>


                    <div class="modal-footer">

                        <button type="submit" class="btn btn-success btn-block">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>