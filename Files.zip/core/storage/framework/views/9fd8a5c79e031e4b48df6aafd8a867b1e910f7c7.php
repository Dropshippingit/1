<?php $__env->startSection('css'); ?>
<style>
    .faq-area .left-content-wrapper .card .card-header a:after{
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="faq-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title extra">
                        <h2 class="title"><?php echo e($pt); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-lg-12">
                    <?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="left-content-wrapper"><!-- left content wrapper -->
                        <div id="accordion">
                            <div class="row">
                                <?php $__currentLoopData = $card; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card col-md-6">
                                        <div class="card-header text-center">
                                            <a data-toggle="modal" href="#modal<?php echo e($cad->id); ?>">
                                                <h4><?php echo e($cad->name); ?></h4>
                                                Price: <?php echo e($gnl->cursym); ?> <?php echo e($cad->price); ?>

                                            </a>
                                        </div>
                                    </div>


                                    <div id="modal<?php echo e($cad->id); ?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Confirm Buy</h4>
                                                </div>
                                                <form method="post" action="<?php echo e(route('card.view', $cad->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body text-center">
                                                        <h4 class="text-success">Available Quantity <?php echo e(\App\card::where('sub_category_id', $cad->id)->where('user_id',0)->count()); ?></h4>
                                                        <br>
                                                        <div class="form-group">
                                                            <strong class="col-md-12">Your Buying Quantity</strong>
                                                            <input class="form-control" type="number" name="qty" >
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer" >
                                                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-success">Confirm</button>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                        </div>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div><!-- //.left content wrapper -->
                </div>



            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>