<?php $__env->startSection('content'); ?>

    <div class="tile">
        <div class="tile-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-info">
                            <div class="caption">
                                <h2 style="text-align: center;color: white">Subscriber Header</h2>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-scrollable table-responsive">
                                <form role="form" method="POST" action="<?php echo e(route('admin.subscrive.submit')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <h4>Title</h4>

                                        <input type="text" value="<?php echo e($gnl->subs_title); ?>" class="form-control"
                                               id="contact_number" name="subs_title">
                                    </div>
                                    <div class="form-group">
                                        <h4>Detail</h4>

                                        <input type="text" value="<?php echo e($gnl->subs_des); ?>" class="form-control"
                                               id="contact_number" name="subs_des">
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success btn-block">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="tile">
        <div class="card">
            <div class="card-header bg-info">
                <div class="caption">
                    <h2 style="text-align: center; color: white">Subscribers</h2>
                </div>

            </div>
            <div class="card-body">
                <div class="table-scrollable table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>
                                Serial
                            </th>
                            <th>
                                Email
                            </th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($key+1); ?>

                                </td>
                                <td>
                                    <?php echo e($user->email); ?>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                    </table>
                    <?php echo e($subs->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>