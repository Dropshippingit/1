<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- service area start -->
    <section class="service-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title extra">
                        <h2 class="title"><?php echo e($gnl->practise_header_title); ?></h2>
                        <p><?php echo $gnl->practise_header_des; ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $practs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-6 col-md-6">
                    <div class="single-service-item"><!-- single service item -->
                        <div class="icon">
                            <i style="font-size: 30px;" class="fa fa-<?php echo e($pc->icon); ?>"></i>

                        </div>
                        <div class="content">
                            <h4 class="title"><?php echo e($pc->title); ?></h4>
                            <p><?php echo e($pc->des); ?></p>
                        </div>
                    </div><!-- //. single service item -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    <!-- service area end -->

    <!-- video area start -->
    <section class="video-area video-area-bg grd-overlay" style="background-image: url(<?php echo e(asset('assets/images/video_bg.jpg')); ?>)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="video-area-content">
                        <div class="video-ply-wrapper">
                            <a href="<?php echo e($gnl->welcome_details_youtube); ?>" class="video-play-btn mfp-iframe"><i class="fas fa-play"></i></a>
                        </div>
                        <h2 class="title"><?php echo e($gnl->welcome_details_title); ?></h2>

                        <p><?php echo $gnl->welcome_details_des; ?></p>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- video area end -->

    <!-- testimonial area start -->
    <section class="testimonial-area " id="testimonial_carousel">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="left-content-area"><!-- left content area -->
                        <h3 class="title"><?php echo e($gnl->attorney_header_title); ?></h3>
                        <p><?php echo $gnl->attorney_header_des; ?></p>
                    </div><!-- //.left content area -->
                </div>
                <div class="col-lg-6">
                    <div class="right-content-area"><!-- right content area -->
                        <div class="testimonial-carousel" id="testimonial-carousel"><!-- testimonial carsouel -->
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-testimonial-carousel"><!-- single testimonial carousel -->
                                <div class="author-details">
                                    <div class="pro-immage">
                                        <img src="<?php echo e(asset($data->image)); ?>" alt="card banner">
                                    </div>
                                    <div class="content">
                                        <h4 class="title"><?php echo e($data->cat_name); ?></h4>
                                        <span class="post">Card Name-<?php echo e($data->cat_name); ?></span>
                                    </div>
                                </div>
                            </div><!-- //.single testimonial carousel -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </div><!-- //. testiomonial carousel -->
                    </div><!-- //. right content area -->
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial area end -->

    <!-- achivment area start -->
    <section class="achivement-area gray-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title">
                        <h2 class="title"><?php echo e($gnl->static_head); ?></h2>
                        <p><?php echo e($gnl->static_des); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $statuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="single-achivement-item"><!-- single achivement item -->
                        <div class="number">
                            <span class="num-count"><?php echo e($st->amount); ?></span>
                        </div>
                        <h4 class="title"><?php echo e($st->title); ?></h4>
                    </div><!-- //.single achivement item -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- achivment area end -->

    <!-- faq area start -->
    <section class="faq-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title extra">
                        <h2 class="title"><?php echo e($gnl->faq_title); ?></h2>
                        <p><?php echo e($gnl->faq_des); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-lg-12">
                    <div class="left-content-wrapper"><!-- left content wrapper -->
                        <div id="accordion">
                           <div class="row">
                               <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <div class="card col-6">
                                   <div class="card-header" id="headingOne<?php echo e($ft->id); ?>">
                                       <a  data-toggle="collapse" data-target="#collapseOne<?php echo e($ft->id); ?>" aria-expanded="false" aria-controls="collapseOne">
                                           <?php echo e($ft->title); ?>

                                       </a>
                                   </div>

                                   <div id="collapseOne<?php echo e($ft->id); ?>" class="collapse" aria-labelledby="headingOne<?php echo e($ft->id); ?>" data-parent="#accordion">
                                       <div class="card-body">
                                           <?php echo $ft->sortdes; ?>

                                       </div>
                                   </div>
                               </div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                    </div><!-- //.left content wrapper -->
                </div>



            </div>
        </div>
    </section>
    <!-- faq area end -->

    <!-- maketing area start -->
    <section class="marketing-area gray-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <div class="marekting-inner">
                        <h2 class="title"><?php echo e($gnl->subs_title); ?></h2>
                        <p><?php echo e($gnl->subs_des); ?></p>
                        <div class="subscribe-form-wapper">
                            <form action="<?php echo e(route('subscript')); ?>" method="post" class="subscribe-form">
                                <?php echo csrf_field(); ?>
                                <div class="form-element">
                                    <input type="email" name="email" class="input-field" required placeholder="Enter your email...">
                                </div>
                                <input type="submit" class="submit-btn" value="Subscribe now">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- maketing area end -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>