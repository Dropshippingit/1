<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- testimonial page content area start-->

    <div class="blog-page-conent">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog-post"><!-- single blog page -->
                        <div class="thumb">
                            <img src="<?php echo e(asset($cat->image)); ?>" alt="card banner images">
                        </div>
                        <div class="content text-center">
                            <a href="<?php echo e(route('category.card',$cat->id)); ?>"><h4 class="title"><?php echo e($cat->cat_name); ?></h4></a>

                            <a href="<?php echo e(route('category.card',$cat->id)); ?>" class="btn btn-info btn-block">Select</a>
                        </div>
                    </div><!-- //. single blog page content -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <!-- testimonial page content area end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>